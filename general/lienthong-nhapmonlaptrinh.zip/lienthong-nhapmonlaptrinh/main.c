#include <stdio.h>

int main(){
    int b = 0;
    printf("Nhap b= ");
    scanf("%d", &b);
    printf("%d",b);
    return 0;
}