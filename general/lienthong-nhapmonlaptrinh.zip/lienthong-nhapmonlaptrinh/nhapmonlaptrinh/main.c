#include <stdio.h>

int tinhtiendien() {
    float soKwSuDung = 0.0;
    double tienPhaiTra = 0.0;
    printf("Nhap So Kw Su Dung: ");
    scanf("%f", &soKwSuDung);
    if (soKwSuDung <= 0) {
        printf("So kw phai >= 0 ");
    }
    if (soKwSuDung > 200) {
        tienPhaiTra = (soKwSuDung - 200) * 2500 + 100 * 1500 + 100 * 1000;
    }
    if (soKwSuDung > 100 && soKwSuDung < 200) {
        tienPhaiTra = (soKwSuDung - 100) * 1500 + 100 * 1000;
    }
    if (soKwSuDung <= 100) {
        tienPhaiTra = soKwSuDung * 1000;
    }
    printf("So Tien Phai Tra cho %.2f Kw dien su dung la: %.2f", soKwSuDung, tienPhaiTra);
    return 0;
}

int ngaycuathang() {
    int ngay = 0;
    int thang = 0;
    int nam = 0;
    printf("Nhap nam: ");
    scanf("%d", &nam);
    if (nam < 0) {
        printf("Nam lon hon hoac bang 0");
        return -1;
    }
    printf("Nhap thang: ");
    scanf("%d", &thang);
    if (thang < 1 || thang > 12) {
        printf("1 <= thang <= 12");
        return -1;
    }
    printf("Nhap ngay: ");
    scanf("%d", &ngay);
    if (ngay < 1 || ngay > 31) {
        printf("1 <= ngay <= 31");
        return -1;
    }
    switch (thang) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            return 31;
        case 4:
        case 6:
        case 9:
        case 11:
            return 30;
        case 2:
            if ((nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0)) {
                return 29;
            }
            return 28;
        default:
            return -1;
    }
}


int phuongrinhbacnhat() {
    float b = 0.0, c = 0.0, x = 0.0;
    printf("Nhap B: ");
    scanf("%f", &b);
    printf("Nhap C: ");
    scanf("%f", &b);

    if (b == 0) {
        printf("Phuong trinh %fx + %f co vo so nghiem", b, c);
    }
    printf("Nghiem cua phuong trinh %fx + %f ", b, c, (c) / b);

    return 0;
}

int in() {
    int tong = 0;
    int n = 0;
    printf("Nhap N: ");
    scanf("%d", &n);

    for (int i = 0; i <= n; i++) {
        tong += i;
    }
    printf("Tong la: %d", tong);
    return 0;
}

bool timSoNguyenTo

void intSao() {
    int h = 0;
    printf("Nhap H = ");
    scanf("%d", &h);
    for (int i = 1; i <= h; i++) {
        for (int j = 1; j <= h; j++) {
            printf("*");
        }
        printf("\n");
    }
}

int main() {
    intSao();
    return 0;
}
