// ReadWriteFile1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "string.h"

typedef struct
{
	char MS[40];
	char Ten[40];
	float DTB;
}SV;

//nhap thong tin cua 5 sinh vien
void WriteFile(char *fileName)
{
	FILE *f;
	SV s;
	int i;
	float DiemTam;
	f=fopen(fileName,"wb");
	if(f==NULL)
	{
		printf("mo khong duoc");
		return;
	}
	else
	{	
		for(i=0;i<3;i++)
		{
			printf("Nhap ma so:");
			fflush(stdin);//xoa vung dem ban phim
			
			gets(s.MS);
			fflush(stdin);//xoa vung dem ban phim
			printf("Nhap ten");
			gets(s.Ten);
			printf("nhap diem trung binh:");
			scanf("%f",&DiemTam);
			s.DTB=DiemTam;
			fwrite(&s,sizeof(SV),1,f);
		}
		
	}
	fclose(f);
}

//nhap thong tin cua cac sinh vien cho den khi ten la rong
void WriteFile1(char *fileName)
{
	FILE *f;
	SV s;
	int i;
	float DiemTam;
	f=fopen(fileName,"wb");
	if(f==NULL)
	{
		printf("mo khong duoc");
		return;
	}
	else
	{	
		do
		{
			printf("Nhap ma so:");
			fflush(stdin);//xoa vung dem ban phim
			gets(s.MS);
			if(strlen(s.MS)>0)
			{
				
				printf("Nhap ten");
				fflush(stdin);//xoa vung dem ban phim
				gets(s.Ten);
				printf("nhap diem trung binh:");
				scanf("%f",&DiemTam);
				s.DTB=DiemTam;
				fwrite(&s,sizeof(SV),1,f);
			}
			
		}while(strlen(s.MS)>0);
		
	}
	fclose(f);
}


void ReadFile(char *fileName)
{
	FILE *f;
	f=fopen(fileName,"rt");
	SV s;
	if(f==NULL)
	{
		printf("Khong mo file duoc");
		return;
	}
	else
	{
		printf("MS\t\tTen\t\tDTB\n");
		while(fread(&s,sizeof(SV),1,f)!=0)
		{
			printf("%s\t\t%s\t\t%0.2f\n",s.MS,s.Ten,s.DTB);
		}
	}
	fclose(f);
}

int main(int argc, char* argv[])
{
	printf("Hello World!\n");
	char TenFile[40];
	strcpy(TenFile,"data.bin");
	//WriteFile1(TenFile);
	ReadFile(TenFile);
	return 0;
}
